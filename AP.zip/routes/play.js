const express = require('express');
const axios = require('axios');
const { youtubeSearch } = require('@bochilteam/scraper-youtube');

const router = express.Router();

const getYouTubeData = async (query) => {
  if (!query) {
    throw new Error('Query parameter is required');
  }

  try {
    const data = await youtubeSearch(query);
    if (data.video.length === 0) {
      throw new Error('No video found');
    }

    const topResult = data.video[0];
    const videoId = new URL(topResult.url).searchParams.get('v');
    const payload = {
      r: '932498fff',
      id: videoId,
      t: Date.now(),
    };

    const headers = {
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
      'Referer': 'https://ytmp3.nexus/',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
      'Connection': 'keep-alive',
      'Accept-Language': 'en-US,en;q=0.9',
    };

    const response = await axios.post('https://ytmp3.nexus/get.php', null, {
      params: payload,
      headers: headers,
    });

    const responseData = response.data;

    // Memeriksa apakah respons valid
    if (responseData && responseData.status === '1' && responseData.download_url) {
      const downloadLinksArray = [
        { url: responseData.download_url, type: responseData.format },
      ];

      const resultToDisplay = {
        url: topResult.url,
        title: topResult.title,
        thumbnail: topResult.thumbnail,
        description: topResult.description,
        publishedTime: topResult.publishedTime,
        viewH: topResult.viewH,
        durationH: topResult.durationH,
        mp3link: downloadLinksArray,
      };

      return { result: resultToDisplay };
    } else {
      throw new Error('Download link not available');
    }

  } catch (error) {
    console.error('Error di getYouTubeData:', error);
    throw new Error('Failed to retrieve YouTube data: ' + error.message);
  }
};

router.get('/', async (req, res) => {
  try {
    const result = await getYouTubeData(req.query.q);
    return res.json(result);
  } catch (error) {
    console.error(error);
    // Mengirimkan status 500 dengan pesan error yang lebih spesifik
    return res.status(500).json({ error: error.message });
  }
});

module.exports = router;
