const express = require('express');
const puppeteer = require('puppeteer');
const path = require('path');
const fs = require('fs');

const router = express.Router();

router.get('/', async (req, res) => {
    const { text } = req.query;

    if (!text) {
        return res.status(400).json({ error: 'Parameter "text" diperlukan' });
    }

    try {
        // URL target dengan parameter
        const url = `https://bratgen.vercel.app/?text=${encodeURIComponent(text)}&preset=bratdeluxe`;

        // Jalankan Puppeteer dalam mode headless dengan Chromium custom path
        const browser = await puppeteer.launch({
            headless: true, // Mode headless untuk server tanpa GUI
            executablePath: '/snap/bin/chromium', // Path ke Chromium
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--disable-gpu',
                '--no-first-run',
                '--no-zygote',
                '--single-process', // Diperlukan jika sandbox dinonaktifkan
                '--disable-background-networking',
                '--disable-default-apps',
                '--disable-extensions',
                '--disable-sync',
                '--hide-scrollbars',
                '--metrics-recording-only',
                '--mute-audio',
                '--no-sandbox',
            ],
        });

        const page = await browser.newPage();
        await page.goto(url, { waitUntil: 'networkidle2' });

        // Tunggu elemen yang dimaksud muncul
        await page.waitForSelector('div.absolute.inset-0.z-10.flex.h-full.w-full.resize-none.items-center.justify-center.overflow-hidden.text-center.text-4xl.outline-none', { timeout: 20000 });

        // Pilih elemen yang ingin di-screenshot
        const element = await page.$('div.absolute.inset-0.z-10.flex.h-full.w-full.resize-none.items-center.justify-center.overflow-hidden.text-center.text-4xl.outline-none');

        if (!element) {
            throw new Error('Elemen preview tidak ditemukan.');
        }

        // Simpan tangkapan layar elemen ke file
        const outputDir = path.join(__dirname, '..', 'output');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir);
        }

        const outputFilePath = path.join(outputDir, `${text}.jpg`);
        await element.screenshot({ path: outputFilePath, type: 'jpeg', quality: 100 });

        // Tutup browser
        await browser.close();

        // Kirim file gambar sebagai respons
        res.sendFile(outputFilePath);
    } catch (error) {
        console.error('Error:', error.message);
        res.status(500).json({ error: 'Terjadi kesalahan saat mengambil gambar' });
    }
});

module.exports = router;
