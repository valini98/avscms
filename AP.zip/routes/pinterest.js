const express = require('express');
const { pinterest } = require('@bochilteam/scraper-images');
const router = express.Router();

const getRandomItem = (array) => {
  return array[Math.floor(Math.random() * array.length)];
};

const pinterestScraper = async (query) => {
  if (!query) {
    throw new Error('Query parameter is required');
  }

  try {
    const data = await pinterest(query);
    
    const filteredImages = data.filter(image => {
      return !image.includes('60x60') && !image.includes('70x75') && !image.includes('140x140');
    });

    if (filteredImages.length === 0) {
      throw new Error('No images found excluding 60x60 and 70x75 resolutions');
    }

    const randomImage = getRandomItem(filteredImages);
    return randomImage;
  } catch (error) {
    throw new Error('An error occurred while fetching data: ' + error.message);
  }
};

router.get('/', async (req, res) => {
  const query = req.query.query;

  try {
    const randomImage = await pinterestScraper(query);
    res.json({ image: randomImage });
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;