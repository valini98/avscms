const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');

const router = express.Router();

async function scrapeTiktokVideo(tiktokUrl) {
    const url = 'https://ttsave.app/download';

    const postData = new URLSearchParams({
        query: tiktokUrl,
        language_id: '1',
    });

    try {
        const response = await axios.post(url, postData, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Language': 'en-US,en;q=0.9',
                'Referer': 'https://ttsave.app/',
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            maxRedirects: 0,
            validateStatus: (status) => true,
        });

        const $ = cheerio.load(response.data);

        let nowmUrl = null;
        $('a[rel="noreferrer noopener"][type="no-watermark"]').each((index, element) => {
            const url = $(element).attr('href');
            if (url) {
                nowmUrl = url;
            }
        });
        
        let wmUrl = null;
        $('a[rel="noreferrer noopener"][type="watermark"]').each((index, element) => {
            const url = $(element).attr('href');
            if (url) {
                wmUrl = url;
            }
        });

        let audioUrl = null;
        $('a[rel="noreferrer noopener"][type="audio"]').each((index, element) => {
            const url = $(element).attr('href');
            if (url) {
                audioUrl = url;
            }
        });
        
        let ppUrl = null;
        $('a[rel="noreferrer noopener"][type="profile"]').each((index, element) => {
            const url = $(element).attr('href');
            if (url) {
                ppUrl = url;
            }
        });

        let slides = [];
        $('a[rel="noreferrer noopener"][type="slide"]').each((index, element) => {
            const url = $(element).attr('href');
            if (url) {
                slides.push(url);
            }
        });

        if (slides.length > 0) {
            return {
                slides: slides,
                pp: ppUrl,
                audio: audioUrl
            };
        } else {
            return {
                wm: wmUrl,
                nowm: nowmUrl,
                audio: audioUrl,
                pp: ppUrl
            };
        }
        
    } catch (error) {
        console.error('Error:', error.message);
        return null;
    }
}

router.get('/', async (req, res) => {
    const tiktokUrl = req.query.url;

    if (!tiktokUrl) {
        return res.status(400).json({ error: "URL TikTok tidak boleh kosong." });
    }

    const result = await scrapeTiktokVideo(tiktokUrl);

    if (result) {
        res.json(result);
    } else {
        res.status(500).json({ error: "Terjadi kesalahan saat memproses permintaan." });
    }
});

module.exports = router;