const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');

const router = express.Router();

async function scrapeDouyinVideo(douyinUrl) {
    const url = 'https://tiktokio.com/api/v1/tk-htmx';

    const postData = new URLSearchParams({
        vid: douyinUrl,
        prefix: 'dtGslxrcdcG9raW8uY29t',
    });

    try {
        const response = await axios.post(url, postData, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Language': 'en-US,en;q=0.9',
                'Referer': 'https://ttsave.app/',
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            maxRedirects: 0,
            validateStatus: (status) => true,
        });

        if (typeof response.data === 'string') {
            const $ = cheerio.load(response.data);

            let links = $('.tk-down-link');
            let linkwm = null;
            let linknowm = null;
            let linkaudio = null;

            links.each((index, element) => {
                const aTag = $(element).find('a');
                const link = aTag.attr('href');

                if (link) {
                    if (index === 1) {
                        linknowm = link;
                    } else if (index === 2) {
                        linkwm = link;
                    } else if (index === 3) {
                        linkaudio = link;
                    }
                }
            });

            return {
                wm: linkwm,
                nowm: linknowm,
                audio: linkaudio,
            };
        } else if (typeof response.data === 'object') {
          
            const { wm, nowm, audio } = response.data;

            return {
                wm: wm || null,
                nowm: nowm || null,
                audio: audio || null,
            };
        } else {
            throw new Error('!!!');
        }
    } catch (error) {
        console.error('Error:', error.message);
        return null;
    }
}

router.get('/', async (req, res) => {
    const douyinUrl = req.query.url;

    if (!douyinUrl) {
        return res.status(400).json({ error: "URL Douyin tidak boleh kosong." });
    }

    const result = await scrapeDouyinVideo(douyinUrl);

    if (result) {
        res.json(result);
    } else {
        res.status(500).json({ error: "Terjadi kesalahan saat memproses permintaan." });
    }
});

module.exports = router;