
const express = require('express');
const path = require('path');
const tiktokRoutes = require('./routes/tiktok');
const douyinRoutes = require('./routes/douyin');
const pinterestRoutes = require('./routes/pinterest');
const playScraperRoutes = require('./routes/play');
const bratRoutes = require('./routes/brat');
const app = express();
const PORT = process.env.PORT || 14762;

let apiHitCount = 0;
const apiStatus = 'Aktif';

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/api/brat', bratRoutes);
app.use('/api/tiktok', tiktokRoutes);
app.use('/api/douyin', douyinRoutes);
app.use('/api/pinterest', pinterestRoutes);
app.use('/api/play', playScraperRoutes);

app.get('/', (req, res) => {
  const domain = `http://localhost:${PORT}`;
  res.render('index', { apiStatus, domain });
});

app.listen(PORT, () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);
});
